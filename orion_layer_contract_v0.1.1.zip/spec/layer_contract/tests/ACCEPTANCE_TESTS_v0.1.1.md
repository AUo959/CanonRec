# Layer Contract Acceptance Tests (v0.1.1)

These map 1:1 to unit/integration tests. Each test MUST assert both outcome and emitted audit artifacts.

## A) Capability Separation (Security Model)
1. **L2 cannot write L1 store**: attempt direct write -> denied (auth/route absent) + audit event emitted.
2. **L2 cannot write canon store**: same as above.
3. **Credential boundary**: verify L2 process has no credentials for L1/canon; rotating secrets does not grant access.

## B) Schema Validation
4. **Envelope required fields**: missing any required envelope field -> reject.
5. **Lineage non-empty**: non-bootstrap messages with empty lineage -> reject.
6. **Bootstrap escape hatch**: bootstrap=true with empty lineage passes only if bootstrap_reason present.

## C) Gate Fail-Fast Behavior
7. **Feasibility FAIL blocks**: reject MutationRequest; ensure audit receipt emitted.
8. **Ethics FAIL blocks**: reject; audit emitted.
9. **Ethics ESCALATE blocks without review**: reject unless review_ref exists.
10. **Continuity FAIL blocks**: reject; audit emitted.

## D) WARN Policy Behavior
11. **WARN requires annotation + ack**: if feasibility= WARN and warn_annotation/operator_ack missing -> reject.
12. **WARN with annotation passes (policy permitting)**: accept if policy says WARN-allowed; audit includes operator_ack.
13. **WARN not silently promoted**: promotion requires explicit request_promotion + authorized identity.

## E) Evidence Gate (EG) (optional in v0.1.1)
14. **SUPPORTED claims require provenance refs**: EG fails if any SUPPORTED claim lacks provenance_refs.
15. **ASSUMPTION/UNKNOWN allowed**: EG passes when claims are marked ASSUMPTION/UNKNOWN without provenance.
16. **EG failure blocks promotion (policy-defined)**: verify EG fail prevents promotion; (may still allow runtime apply if policy allows).

## F) Cadence & Tone Linter (CTL) (optional in v0.1.1)
17. **Overclaim flagged**: messages missing uncertainty markers when required -> CTL warns/fails per policy.
18. **Layer-bleed phrasing flagged**: e.g., “L2 overwrote L1” -> CTL fail.
19. **Canon confusion flagged**: “chat said it so it’s canon” -> CTL fail.

## G) Determinism / Replay Harness
20. **Same bundle -> identical L2 outputs**: run twice with same continuity bundle -> identical deltas/exports.
21. **Bundle change -> non-equivalence**: modify any bundle field -> system labels “new run”; does not claim equivalence.
22. **No hidden wall-clock**: if wall-clock used but not declared -> continuity fails.

## H) Promotion Authorization
23. **Unauthorized promoter rejected**: request_promotion=true with invalid identity -> reject.
24. **Missing metadata rejected**: promotion requested without required receipts/manifest -> reject.
25. **Promotion emits immutable ledger event**: on success, verify commit/merge (or ledger write) and returned stable receipts.

## I) Lineage Traceability
26. **MutationRequest must reference Proposal lineage (policy-required)**: enforce via schema/policy; reject if missing.
27. **End-to-end trace**: given a promoted L1 change, reconstruct Observation -> Proposal -> MutationRequest chain.

## J) Audit Completeness
28. **Every decision audited**: accept/reject paths both emit audit records.
29. **Receipts hashed**: receipts contain stable hash fields; verify canonicalization of hash inputs.
