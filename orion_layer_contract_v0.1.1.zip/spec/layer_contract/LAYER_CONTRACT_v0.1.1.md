# Layer Contract Spec v0.1.1 (Contract-Hardening Revision)

> **Intent:** convert clear prose into mechanically enforceable “physics” that prevents layer-bleed and drift-by-accumulation.

## 1) Canon vs Runtime State (explicit separation)

- **L1 runtime state mutation** may occur *without* canon promotion (e.g., scratchpad runs, reversible trial patches, ephemeral UI state).
- **Promotion** is a separate *optional* step that writes to the immutable canon ledger / SSOT and is the only act that makes content canonical.

**Rule:** A MutationRequest MAY set `apply_to_l1_runtime=true` and `request_promotion=false`.  
**Rule:** `request_promotion=true` requires an authorized promoter identity and complete metadata/receipts.

## 2) Gates (triad + two always-on output gates)

**Core triad (required):**
- Feasibility Gate (PASS/WARN/FAIL)
- Ethics Gate (PASS/FAIL/ESCALATE)
- Continuity Gate (PASS/FAIL)

**Output discipline gates (optional in v0.1.1, recommended always-on; v0.2 may require):**
- **Evidence Gate (EG):** no staged-input claim without provenance pointers or explicit `ASSUMPTION/UNKNOWN`.
- **Cadence & Tone Linter (CTL):** an anti-overclaim / anti-layer-bleed linter that enforces uncertainty markers and blocks canon-confusion phrasing.

## 3) WARN policy (anti WARN-creep)

If feasibility verdict is `WARN`, the MutationRequest must include:
- `warn_annotation` (why WARN is acceptable)
- `operator_ack` (human or authorized service acknowledgement)

Otherwise the request is blocked.

## 4) Lineage (required; bootstrap escape hatch only)

Lineage is required for auditability:
- `lineage` MUST be non-empty for all non-bootstrap messages.
- Escape hatch: `bootstrap=true` permits empty lineage only with `bootstrap_reason`.

## 5) Capability separation (policy -> security model)

Capability separation is enforced by **process boundaries + ACLs**:
- L2 runtimes lack credentials/API routes required to write L1 or canon stores.
- Any attempt to bypass is a hard failure and must be audited.

## 6) Allowed clock set (starter set locked)

Allowed clocks:
- `CLOCK_TICK_L2`
- `MISSION_ELAPSED_TIME_L1`
- `WALL_CLOCK` (allowed only if explicitly declared with a reason)

**Rule:** Any wall-clock use must appear in the continuity bundle or continuity fails.

## 7) Uncertainty semantics (numbers with discipline)

Either:
- Qualitative `uncertainty_band: LOW|MED|HIGH`, or
- Numeric `confidence: 0..1` **only if** a calibration method is declared (`calibration_ref` and optionally a hash).

Teams must not invent uncalibrated “0.83 confidence” numbers.

## 8) Repo layout (ergonomic + future-proof)

- `/spec/layer_contract/LAYER_CONTRACT_v0.1.1.md`
- `/spec/layer_contract/schemas/`
- `/spec/layer_contract/tests/`
